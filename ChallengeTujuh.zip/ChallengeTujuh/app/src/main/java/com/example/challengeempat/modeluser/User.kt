package com.example.challengeempat.modeluser

data class User( val username: String = "",
                 val noTelepon: String = "",
                 val email: String = "")
