package com.example.challengeempat.model


data class OrderItem(val nama: String,
                     val qty: Int,
                     val catatan: String,
                     val harga: Int

)