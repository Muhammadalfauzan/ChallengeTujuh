package com.example.challengeempat.model


data class OrderResponse(
    val status: Boolean,
    val message: String,
    val code: Int
)